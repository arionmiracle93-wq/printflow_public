import Link from "next/link";
import { notFound } from "next/navigation";
import type { ReactNode } from "react";
import { AlertTriangle, Bot, Clock, Factory, History, Image as ImageIcon, Package, PackageCheck, StickyNote, UserRound, Wallet } from "lucide-react";
import { OrderQuickEdit, OrderStatusControls } from "@/components/OrderControls";
import { OrderDetailTabs } from "@/components/OrderDetailTabs";
import { OrderItemsManager } from "@/components/OrderItemsManager";
import { summarizeItems } from "@/lib/order-items";
import { PhotoManager } from "@/components/PhotoManager";
import { ShareWhatsApp } from "@/components/ShareWhatsApp";
import { OutsourceManager } from "@/components/OutsourceManager";
import { HandoverManager } from "@/components/HandoverManager";
import { listHandovers, type HandoverRecord } from "@/lib/handover-queries";
import { ProblemScreen } from "@/components/ProblemScreen";
import { ProduksiFrame } from "@/components/ProduksiSidebar";
import { AiInsightCard } from "@/components/AiInsightCard";
import { listOutsource, listPartners } from "@/lib/outsource-queries";
import { outsourceStatusMeta } from "@/lib/outsource";
import { getCurrentUser } from "@/lib/auth";
import { listActiveEmployees } from "@/lib/user-queries";
import { safeDb } from "@/lib/dbcheck";
import type { AiOrder } from "@/lib/ai";
import { MAX_PHOTOS_PER_ORDER, listPhotos } from "@/lib/queries";
import { PriorityBadge, ProgressBar, RiskBadge, STATUS_ICONS, StatusBadge } from "@/components/ui";
import { analyzeOrder } from "@/lib/ai";
import { OrderInvoiceCard } from "@/components/OrderInvoiceCard";
import {
  MACHINES,
  STATUSES,
  deadlineOf,
  formatDateID,
  formatDateTimeID,
  formatRupiah,
  humanDuration,
  statusMeta,
} from "@/lib/domain";
import { getAiNotes, getOrderById, getOrderEvents, listCustomers } from "@/lib/queries";

export const dynamic = "force-dynamic";

/** Sisa jam dihitung di helper, bukan langsung di body komponen. */
function sisaJam(order: AiOrder) {
  const deadline = deadlineOf(order.dueDate, order.dueTime);
  return (deadline.getTime() - Date.now()) / 3_600_000;
}

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const orderId = Number.parseInt(id, 10);
  if (!Number.isFinite(orderId)) notFound();

  const loaded = await safeDb(async () => {
    const [order, sessionUser] = await Promise.all([getOrderById(orderId), getCurrentUser()]);
    if (!order) return null;
    const [events, notes, photos, outsource, partners, handovers, employees, customers] = await Promise.all([
      getOrderEvents(orderId),
      getAiNotes(orderId),
      listPhotos(orderId),
      listOutsource(orderId),
      listPartners(),
      listHandovers(orderId),
      listActiveEmployees(sessionUser?.role === "karyawan" ? sessionUser.id : undefined),
      listCustomers(),
    ]);
    return { order, events, notes, photos, outsource, partners, handovers, sessionUser, employees, customers };
  });
  if (!loaded.ok) {
    // Tabel foto mungkin belum ada (deploy lama). Coba tanpa foto agar halaman tetap terbuka.
    const fallback = await safeDb(async () => {
      const order = await getOrderById(orderId);
      if (!order) return null;
      const [events, notes] = await Promise.all([getOrderEvents(orderId), getAiNotes(orderId)]);
      return { order, events, notes };
    });
    if (!fallback.ok) {
      return <ProblemScreen problem={loaded.problem} hint="Detail pekerjaan dibaca dari database." />;
    }
    if (!fallback.data) notFound();
    const order = fallback.data.order;
    const insight = analyzeOrder(order);
    const meta = statusMeta(order.status);
    return (
      <ProduksiFrame>
      <div className="space-y-4">
        <UpgradeNotice />
        <FallbackDetailBody order={order} events={fallback.data.events} notes={fallback.data.notes} insight={insight} meta={meta} />
      </div>
      </ProduksiFrame>
    );
  }
  if (!loaded.data) notFound();

  const order = loaded.data.order;

  return (
    <DetailBody
      order={order}
      events={loaded.data.events}
      notes={loaded.data.notes}
      photos={loaded.data.photos}
      insight={analyzeOrder(order)}
      meta={statusMeta(order.status)}
      outsource={loaded.data.outsource}
      partners={loaded.data.partners}
      handovers={loaded.data.handovers}
      sessionUser={loaded.data.sessionUser}
      employees={loaded.data.employees}
      customers={loaded.data.customers}
    />
  );
}

/** Kartu peringatan bila tabel foto belum dibuat di database pengguna. */
function UpgradeNotice() {
  return (
    <div className="card border-amber-200 bg-amber-50 p-4">
      <p className="flex items-center gap-1.5 text-sm font-bold text-amber-900">
        <ImageIcon size={15} /> Fitur foto siap dipakai - satu langkah lagi
      </p>
      <p className="mt-1 text-xs text-amber-800">
        Tabel penyimpan foto belum ada di database Anda. Buka alamat ini sekali di browser, lalu kembali ke halaman ini:
      </p>
      <p className="mt-2 rounded-lg bg-white px-3 py-2 text-xs font-semibold text-amber-900">
        https://alamat-aplikasi-anda.vercel.app/api/setup
      </p>
      <p className="mt-1 text-[11px] text-amber-700">
        Aman dijalankan berulang - tidak menghapus data apa pun.
      </p>
    </div>
  );
}

/** Header ringkas - tetap terlihat di atas, sebelum tab apa pun dibuka. */
function OrderHeader({
  order,
  insight,
}: {
  order: AiOrder;
  insight: ReturnType<typeof analyzeOrder>;
}) {
  return (
    <div className="card p-4 md:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-bold tracking-wide text-teal-700 dark:text-teal-300">{order.code}</p>
          <h1 className="page-title truncate">{order.title}</h1>
          <p className="text-xs text-slate-600 md:text-sm">
            {order.customerName} · dibuat {formatDateTimeID(order.createdAt)}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={order.status} />
          <PriorityBadge priority={order.priority} />
          <RiskBadge level={insight.riskLevel} score={insight.riskScore} />
        </div>
      </div>
    </div>
  );
}

function DetailBody({
  order,
  events,
  notes,
  photos,
  insight,
  meta,
  outsource,
  partners,
  handovers,
  sessionUser,
  employees,
  customers,
}: {
  order: AiOrder;
  events: Awaited<ReturnType<typeof getOrderEvents>>;
  notes: Awaited<ReturnType<typeof getAiNotes>>;
  photos: Awaited<ReturnType<typeof listPhotos>>;
  insight: ReturnType<typeof analyzeOrder>;
  meta: ReturnType<typeof statusMeta>;
  /** Semua mitra pekerjaan ini (bisa lebih dari satu). */
  outsource: Awaited<ReturnType<typeof listOutsource>>;
  partners: Awaited<ReturnType<typeof listPartners>>;
  handovers: HandoverRecord[];
  sessionUser: Awaited<ReturnType<typeof getCurrentUser>>;
  employees: Awaited<ReturnType<typeof listActiveEmployees>>;
  customers: Awaited<ReturnType<typeof listCustomers>>;
}) {
  const hoursLeft = sisaJam(order);
  const outstanding = Math.max(0, order.price - order.paidAmount);
  // Untuk jaring pengaman "tandai Selesai": ambil mitra yang belum
  // diterima (kalau ada), supaya peringatannya tetap muncul.
  const outsourceStatus = outsource.find((j) => j.status !== "diterima")?.status ?? outsource[0]?.status ?? null;

  // Indikator tab - murni dari data yang sudah dimuat, tidak ada logic/query baru.
  const mitraActive = outsource.some((j) => j.status !== "diterima");
  const komunikasiPending = handovers.some((h) => !h.acceptedAt);

  // ------------------------------------------------------------------
  // Panel samping kanan (desktop lebar, >=1280px) - "sekilas pekerjaan".
  // Tampil di SEMUA tab, jadi info terpenting tetap kelihatan walau
  // operator sedang di tab Foto/Mitra/Komunikasi. Murni dari data yang
  // sudah dimuat di atas: tidak ada query baru.
  // ------------------------------------------------------------------
  const isLate = hoursLeft < 0 && !meta.done && order.status !== "siap";
  const timeTone = order.status === "siap" || meta.done ? "text-emerald-600" : isLate ? "text-rose-600" : "text-slate-900";
  const timeText =
    order.status === "siap" ? "Siap diambil" : meta.done ? "Selesai" : isLate ? `Terlambat ${humanDuration(hoursLeft)}` : humanDuration(hoursLeft);
  const paidPct = order.price > 0 ? Math.min(100, Math.round((order.paidAmount / order.price) * 100)) : 0;
  const lunas = outstanding <= 0;

  const railContent = (
    <>
      <div className="card p-4">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
          <Clock size={12} /> Sisa waktu
        </p>
        <p className={`mt-1 flex items-center gap-1.5 text-2xl font-bold leading-tight ${timeTone}`}>
          {isLate ? <AlertTriangle size={20} className="shrink-0" /> : order.status === "siap" ? <PackageCheck size={20} className="shrink-0" /> : null}
          {timeText}
        </p>
        <p className="mt-0.5 text-xs text-slate-500">
          Deadline {formatDateID(order.dueDate)} · {order.dueTime}
        </p>
        <div className="mt-3">
          <div className="mb-1 flex items-center justify-between text-[11px] font-semibold text-slate-500">
            <span>{meta.short}</span>
            <span>{meta.progress}%</span>
          </div>
          <ProgressBar value={meta.progress} tone={meta.bar} />
        </div>
      </div>

      <div className="card p-4">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-slate-500">
          <Wallet size={12} /> Pembayaran
        </p>
        <p className={`mt-1 text-2xl font-bold leading-tight ${lunas ? "text-emerald-600" : "text-rose-600"}`}>
          {lunas ? "Lunas" : formatRupiah(outstanding)}
        </p>
        <p className="mt-0.5 text-xs text-slate-500">{lunas ? "Tidak ada sisa tagihan" : "Sisa tagihan"}</p>
        <div className="mt-3">
          <ProgressBar value={paidPct} tone={lunas ? "bg-emerald-500" : "bg-teal-500"} />
        </div>
        <dl className="mt-3 space-y-1 text-xs">
          <div className="flex items-center justify-between gap-3">
            <dt className="text-slate-500">Total harga</dt>
            <dd className="font-semibold text-slate-800">{formatRupiah(order.price)}</dd>
          </div>
          <div className="flex items-center justify-between gap-3">
            <dt className="text-slate-500">Sudah dibayar</dt>
            <dd className="font-semibold text-slate-800">{formatRupiah(order.paidAmount)}</dd>
          </div>
        </dl>
      </div>

      <div className="card p-4">
        <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Detail pekerjaan</p>
        <dl className="mt-2 space-y-2.5 text-xs">
          <div>
            <dt className="text-slate-500">Isi pesanan ({order.items.length} produk)</dt>
            <dd className="mt-0.5 text-[13px] font-semibold leading-snug text-slate-800">{summarizeItems(order.items, 3)}</dd>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <dt className="text-slate-500">Mesin</dt>
              <dd className="mt-0.5 text-[13px] font-semibold text-slate-800">{order.machine}</dd>
            </div>
            <div>
              <dt className="text-slate-500">Operator</dt>
              <dd className="mt-0.5 text-[13px] font-semibold text-slate-800">{order.operator || "-"}</dd>
            </div>
          </div>
          <div>
            <dt className="text-slate-500">Estimasi kerja (AI)</dt>
            <dd className="mt-0.5 text-[13px] font-semibold text-slate-800">± {order.estHours} jam</dd>
          </div>
        </dl>
      </div>
    </>
  );

  // Aktivitas terbaru (3 terakhir). Dibungkus kartu + tombol "lihat semua"
  // oleh OrderDetailTabs, karena tombolnya perlu pindah tab.
  const activityContent = (
    <ol className="space-y-2.5 border-l-2 border-slate-100 pl-3.5">
      {events.length === 0 ? (
        <li className="text-xs text-slate-500">Belum ada riwayat.</li>
      ) : (
        events.slice(0, 3).map((event) => (
          <li key={event.id} className="relative">
            <span className="absolute -left-[19px] top-1 h-2.5 w-2.5 rounded-full border-2 border-white bg-teal-500" />
            <p className="text-xs font-semibold leading-snug text-slate-800">{eventStatusLabel(event.toStatus)}</p>
            <p className="text-[11px] text-slate-500">
              {formatDateTimeID(event.createdAt)} · {event.actor}
            </p>
          </li>
        ))
      )}
    </ol>
  );

  const ringkasanContent = (
    <>
      <div className="card p-4">
        {/* Delapan kartu info (Isi pesanan, Mesin, Deadline, Sisa waktu,
            Total, Dibayar, Sisa tagihan, Estimasi AI).

            Di HP ini dulu satu kolom: perlu ~460px hanya untuk membaca
            ringkasan, sementara progres produksi - yang paling sering
            dicek - ada di bawahnya.

            Sekarang dua kolom di HP, jadi ~230px. Aman berbeda dari kolom
            isian di editor invoice yang juga saya ubah ke satu kolom:
            kartu ini tidak diketik, isinya cuma label dan nilai, jadi
            160px sudah cukup. sm: ke atas tetap 2 kolom, lg: ke atas 4. */}
        {/* Di layar >=1280px kedelapan info ini pindah ke panel samping
            kanan (railContent) supaya tidak tampil dobel - makanya grid
            ini disembunyikan di sana. Di bawah itu tetap tampil seperti
            biasa. */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:hidden">
          <Info
            label={`Isi pesanan (${order.items.length} produk)`}
            value={summarizeItems(order.items, 3)}
          />
          <Info label="Mesin / Operator" value={`${order.machine}${order.operator ? ` · ${order.operator}` : ""}`} />
          <Info label="Deadline" value={`${formatDateID(order.dueDate)} · ${order.dueTime}`} />
          <Info
            label="Sisa waktu"
            value={
              order.status === "siap" ? (
                // Siap = tinggal menunggu pelanggan, tidak dihitung terlambat.
                <span className="inline-flex items-center gap-1 text-emerald-700">
                  <PackageCheck size={13} /> Siap diambil/dikirim
                </span>
              ) : hoursLeft < 0 && !meta.done ? (
                <span className="inline-flex items-center gap-1">
                  <AlertTriangle size={13} /> Terlambat {humanDuration(hoursLeft)}
                </span>
              ) : meta.done ? (
                "Selesai"
              ) : (
                humanDuration(hoursLeft)
              )
            }
          />
          <Info label="Total harga" value={formatRupiah(order.price)} />
          <Info label="Sudah dibayar" value={formatRupiah(order.paidAmount)} />
          <Info label="Sisa tagihan" value={formatRupiah(outstanding)} tone={outstanding > 0 ? "text-rose-600" : "text-emerald-600"} />
          <Info label="Estimasi kerja (AI)" value={`± ${order.estHours} jam`} />
        </div>

        <div className="mt-4 xl:mt-0">
          <div className="mb-1 flex items-center justify-between text-xs font-semibold text-slate-500">
            <span>Progres produksi</span>
            <span>{meta.progress}%</span>
          </div>
          <ProgressBar value={meta.progress} tone={meta.bar} />
          <div className="mt-2 flex flex-wrap gap-1">
            {STATUSES.filter((s) => !["ditunda", "batal"].includes(s.key)).map((s) => (
              <span
                key={s.key}
                className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                  s.progress <= meta.progress ? "bg-teal-100 text-teal-700" : "bg-slate-100 text-slate-400"
                }`}
              >
                {s.short}
              </span>
            ))}
          </div>
        </div>

        {order.notes ? (
          <p className="mt-4 flex items-start gap-1.5 rounded-xl bg-slate-50 px-3 py-2 text-sm text-slate-700">
            <StickyNote size={14} className="mt-0.5 shrink-0" /> {order.notes}
          </p>
        ) : null}
      </div>

      {/* Rincian produk di dalam pekerjaan ini - bisa langsung diubah di sini. */}
      <OrderItemsManager
        orderId={order.id}
        initialItems={order.items}
        orderStatus={order.status}
        orderDueDate={order.dueDate}
        orderDueTime={order.dueTime}
        jobs={outsource.map((j) => ({ id: j.id, partnerName: j.partnerName }))}
      />

      <AiInsightCard insight={insight} notes={notes} />

      <OrderStatusControls orderId={order.id} currentStatus={order.status} outsourceStatus={outsourceStatus} />
    </>
  );

  const mitraContent = (
    <>
      <OutsourceManager
        orderId={order.id}
        orderPrice={order.price}
        customerDueDate={order.dueDate}
        jobs={outsource}
        items={order.items}
        initialPartners={partners.map((p) => ({
          id: p.id,
          name: p.name,
          kind: p.kind,
          phone: p.phone,
          address: p.address,
          active: p.active,
        }))}
      />
      <Link
        href="/mitra"
        className="card flex items-center justify-between p-4 text-sm font-bold text-teal-700 transition hover:border-teal-300 dark:text-teal-300"
      >
        Lihat semua pekerjaan yang sedang di mitra
        <span aria-hidden>→</span>
      </Link>
    </>
  );

  const komunikasiContent = (
    <>
      <ShareWhatsApp
        order={{
          id: order.id,
          code: order.code,
          title: order.title,
          customerName: order.customerName,
          status: order.status,
          dueDate: order.dueDate,
          dueTime: order.dueTime,
          items: order.items,
        }}
        initialToken={null}
      />
      <HandoverManager
        orderId={order.id}
        orderCode={order.code}
        orderTitle={order.title}
        customerName={order.customerName}
        dueDate={order.dueDate}
        dueTime={order.dueTime}
        currentOperator={order.operator}
        orderStatus={order.status}
        records={handovers}
        loggedInName={sessionUser?.name ?? "Pengguna"}
        loggedInRole={sessionUser?.role ?? "karyawan"}
        employees={employees}
      />
    </>
  );

  const fotoContent = (
    <PhotoManager
      orderId={order.id}
      max={MAX_PHOTOS_PER_ORDER}
      initialPhotos={photos.map((p) => ({
        id: p.id,
        kind: p.kind,
        caption: p.caption,
        sizeBytes: p.sizeBytes,
        url: p.url,
        createdAt: p.createdAt,
      }))}
    />
  );

  const lainnyaContent = (
    <>
      <OrderQuickEdit
        order={{
          id: order.id,
          customerName: order.customerName,
          dueDate: order.dueDate,
          dueTime: order.dueTime,
          priority: order.priority,
          operator: order.operator,
          machine: MACHINES.includes(order.machine) ? order.machine : MACHINES[0],
          price: order.price,
          paidAmount: order.paidAmount,
          notes: order.notes,
        }}
        customers={customers}
        /* Nama karyawan terdaftar, sama seperti di halaman "Pekerjaan
           Baru". Datanya sudah diambil lebih dulu di atas (dipakai
           juga oleh kartu shift), jadi ini tidak menambah kueri. */
        operatorSuggestions={employees.map((e) => e.name)}
      />
      <div className="card p-4">
        <h3 className="flex items-center gap-1.5 text-sm font-bold text-slate-900">
          <History size={16} /> Riwayat / Jejak Produksi
        </h3>
        <p className="text-xs text-slate-500">Siapa mengubah apa dan kapan - berguna saat ada keluhan pelanggan.</p>
        <ol className="mt-3 space-y-3 border-l-2 border-slate-100 pl-4">
          {events.length === 0 ? (
            <li className="text-sm text-slate-500">Belum ada riwayat.</li>
          ) : (
            events.map((event) => {
              const EventIcon = event.toStatus.startsWith("mitra:") ? Factory : event.toStatus.startsWith("produk:") ? Package : STATUS_ICONS[event.toStatus] ?? UserRound;
              return (
                <li key={event.id} className="relative">
                  <span className="absolute -left-[22px] top-1.5 h-3 w-3 rounded-full border-2 border-white bg-teal-500" />
                  <p className="flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                    {event.fromStatus ? `${eventStatusLabel(event.fromStatus)} → ` : ""}
                    <EventIcon size={13} className="shrink-0" />
                    {eventStatusLabel(event.toStatus)}
                  </p>
                  <p className="text-xs text-slate-500">
                    {formatDateTimeID(event.createdAt)} · oleh {event.actor}
                  </p>
                  {event.note ? <p className="mt-0.5 text-xs text-slate-600">&ldquo;{event.note}&rdquo;</p> : null}
                </li>
              );
            })
          )}
        </ol>
      </div>
    </>
  );

  return (
    <OrderDetailTabs
      header={
        <>
          <Link href="/pesanan" className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:underline dark:text-teal-300">
            ← Kembali ke daftar pekerjaan
          </Link>
          <OrderHeader order={order} insight={insight} />
          <OrderInvoiceCard orderId={order.id} />
        </>
      }
      ringkasan={ringkasanContent}
      mitra={mitraContent}
      komunikasi={komunikasiContent}
      foto={fotoContent}
      lainnya={lainnyaContent}
      rail={railContent}
      activity={activityContent}
      mitraActive={mitraActive}
      komunikasiPending={komunikasiPending}
    />
  );
}

/** Tampilan lama (satu kolom) - dipakai hanya saat tabel foto belum ada di database (deploy lama). */
function FallbackDetailBody({
  order,
  events,
  notes,
  insight,
  meta,
}: {
  order: AiOrder;
  events: Awaited<ReturnType<typeof getOrderEvents>>;
  notes: Awaited<ReturnType<typeof getAiNotes>>;
  insight: ReturnType<typeof analyzeOrder>;
  meta: ReturnType<typeof statusMeta>;
}) {
  const hoursLeft = sisaJam(order);
  const outstanding = Math.max(0, order.price - order.paidAmount);

  return (
    <ProduksiFrame>
    <div className="space-y-4">
      <Link href="/pesanan" className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:underline dark:text-teal-300">
        ← Kembali ke daftar pekerjaan
      </Link>

      <div className="card p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-xs font-bold tracking-wide text-teal-700 dark:text-teal-300">{order.code}</p>
            <h1 className="text-xl font-semibold text-slate-900 md:text-2xl">{order.title}</h1>
            <p className="text-sm text-slate-600">
              {order.customerName} · dibuat {formatDateTimeID(order.createdAt)}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={order.status} />
            <PriorityBadge priority={order.priority} />
            <RiskBadge level={insight.riskLevel} score={insight.riskScore} />
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2 sm:gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Info
            label={`Isi pesanan (${order.items.length} produk)`}
            value={summarizeItems(order.items, 3)}
          />
          <Info label="Mesin / Operator" value={`${order.machine}${order.operator ? ` · ${order.operator}` : ""}`} />
          <Info label="Deadline" value={`${formatDateID(order.dueDate)} · ${order.dueTime}`} />
          <Info
            label="Sisa waktu"
            value={
              order.status === "siap" ? (
                // Siap = tinggal menunggu pelanggan, tidak dihitung terlambat.
                <span className="inline-flex items-center gap-1 text-emerald-700">
                  <PackageCheck size={13} /> Siap diambil/dikirim
                </span>
              ) : hoursLeft < 0 && !meta.done ? (
                <span className="inline-flex items-center gap-1">
                  <AlertTriangle size={13} /> Terlambat {humanDuration(hoursLeft)}
                </span>
              ) : meta.done ? (
                "Selesai"
              ) : (
                humanDuration(hoursLeft)
              )
            }
          />
          <Info label="Total harga" value={formatRupiah(order.price)} />
          <Info label="Sudah dibayar" value={formatRupiah(order.paidAmount)} />
          <Info label="Sisa tagihan" value={formatRupiah(outstanding)} tone={outstanding > 0 ? "text-rose-600" : "text-emerald-600"} />
          <Info label="Estimasi kerja (AI)" value={`± ${order.estHours} jam`} />
        </div>

        <div className="mt-4">
          <ProgressBar value={meta.progress} tone={meta.bar} />
        </div>
      </div>

      <OrderStatusControls orderId={order.id} currentStatus={order.status} />

      <div className="card p-4">
        <h3 className="flex items-center gap-1.5 text-sm font-bold text-slate-900">
          <History size={16} /> Riwayat / Jejak Produksi
        </h3>
        <ol className="mt-3 space-y-3 border-l-2 border-slate-100 pl-4">
          {events.length === 0 ? (
            <li className="text-sm text-slate-500">Belum ada riwayat.</li>
          ) : (
            events.map((event) => (
              <li key={event.id} className="relative">
                <span className="absolute -left-[22px] top-1.5 h-3 w-3 rounded-full border-2 border-white bg-teal-500" />
                <p className="text-sm font-semibold text-slate-800">
                  {event.fromStatus ? `${eventStatusLabel(event.fromStatus)} → ` : ""}
                  {eventStatusLabel(event.toStatus)}
                </p>
                <p className="text-xs text-slate-500">
                  {formatDateTimeID(event.createdAt)} · oleh {event.actor}
                </p>
              </li>
            ))
          )}
        </ol>
      </div>
      {notes.length ? (
        <div className="card p-4">
          <p className="text-xs font-bold uppercase tracking-wide text-slate-500">Riwayat catatan AI</p>
          <ul className="mt-1.5 space-y-1 text-[11px] text-slate-600">
            {notes.slice(0, 5).map((n) => (
              <li key={n.id}>
                {formatDateTimeID(n.createdAt)} - {n.message}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
    </ProduksiFrame>
  );
}

function eventStatusLabel(value: string): string {
  if (value.startsWith("mitra:")) return `Mitra - ${outsourceStatusMeta(value.slice(6)).label}`;
  if (value.startsWith("produk:")) return `Produk - ${statusMeta(value.slice(7)).label}`;
  if (value === "shift:menunggu") return "Serah Terima - Menunggu Diterima";
  if (value === "shift:diterima") return "Serah Terima - Sudah Diterima";
  if (value === "shift:aktif") return "Operator Aktif";
  return statusMeta(value).label;
}

function Info({ label, value, tone = "text-slate-800" }: { label: string; value: ReactNode; tone?: string }) {
  return (
    <div className="rounded-xl bg-slate-50 px-3 py-2">
      <p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`text-sm font-semibold ${tone}`}>{value}</p>
    </div>
  );
}
