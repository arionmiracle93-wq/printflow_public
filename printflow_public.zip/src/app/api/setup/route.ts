import { sql } from "drizzle-orm";
import { db } from "@/db";

export const dynamic = "force-dynamic";

const DDL = [
  `CREATE TABLE IF NOT EXISTS customers (
      id serial PRIMARY KEY,
      name text NOT NULL,
      phone text,
      email text,
      address text,
      notes text,
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS orders (
      id serial PRIMARY KEY,
      code text NOT NULL UNIQUE,
      customer_id integer REFERENCES customers(id) ON DELETE SET NULL,
      customer_name text NOT NULL,
      title text NOT NULL,
      machine text NOT NULL DEFAULT 'Digital Print',
      operator text,
      status text NOT NULL DEFAULT 'antrian',
      priority text NOT NULL DEFAULT 'normal',
      price integer NOT NULL DEFAULT 0,
      paid_amount integer NOT NULL DEFAULT 0,
      due_date date NOT NULL,
      due_time text NOT NULL DEFAULT '17:00',
      est_hours integer NOT NULL DEFAULT 4,
      notes text,
      pic text NOT NULL DEFAULT 'Owner',
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
   )`,
  // ITEM PEKERJAAN: rincian produk (jenis + jumlah + satuan) di dalam satu
  // pekerjaan. Satu pekerjaan boleh punya banyak baris item, tapi tetap
  // satu status/mesin/operator/deadline untuk keseluruhan pekerjaan.
  `CREATE TABLE IF NOT EXISTS order_items (
      id serial PRIMARY KEY,
      order_id integer NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      product_type text NOT NULL,
      quantity integer NOT NULL DEFAULT 1,
      unit text NOT NULL DEFAULT 'pcs',
      position integer NOT NULL DEFAULT 0,
      due_date date,
      due_time text,
      source_line_key text,
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items (order_id)`,
  // Migrasi dari versi lama (satu jenis produk per pekerjaan di tabel
  // `orders`) ke tabel `order_items`. Dibungkus DO-block yang mengecek dulu
  // apakah kolom lama masih ada, supaya statement ini aman dijalankan
  // berulang kali (setelah kolomnya di-drop di bawah, blok ini otomatis
  // tidak melakukan apa-apa lagi).
  `DO $$
   BEGIN
     IF EXISTS (
       SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'public'
         AND table_name = 'orders'
         AND column_name = 'product_type'
     ) THEN
       INSERT INTO order_items (order_id, product_type, quantity, unit, position)
       SELECT o.id, coalesce(o.product_type, 'Lainnya'), greatest(coalesce(o.quantity, 1), 1),
              coalesce(o.unit, 'pcs'), 0
       FROM orders o
       WHERE NOT EXISTS (SELECT 1 FROM order_items oi WHERE oi.order_id = o.id);
     END IF;
   END $$`,
  // Setelah dipindahkan ke order_items, kolom jenis produk/jumlah/satuan di
  // tabel orders sudah tidak dipakai lagi — satu pekerjaan sekarang bisa
  // berisi banyak produk sekaligus.
  `ALTER TABLE orders DROP COLUMN IF EXISTS product_type`,
  `ALTER TABLE orders DROP COLUMN IF EXISTS quantity`,
  `ALTER TABLE orders DROP COLUMN IF EXISTS unit`,
  `CREATE TABLE IF NOT EXISTS order_events (
      id serial PRIMARY KEY,
      order_id integer NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      from_status text,
      to_status text NOT NULL,
      note text,
      actor text NOT NULL DEFAULT 'Owner',
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS ai_notes (
      id serial PRIMARY KEY,
      order_id integer REFERENCES orders(id) ON DELETE CASCADE,
      kind text NOT NULL DEFAULT 'insight',
      risk_score integer NOT NULL DEFAULT 0,
      risk_level text NOT NULL DEFAULT 'aman',
      message text NOT NULL,
      source text NOT NULL DEFAULT 'engine',
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS settings (
      key text PRIMARY KEY,
      value text NOT NULL,
      updated_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS order_photos (
      id serial PRIMARY KEY,
      order_id integer NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      kind text NOT NULL DEFAULT 'referensi',
      mime text NOT NULL DEFAULT 'image/jpeg',
      size_bytes integer NOT NULL DEFAULT 0,
      caption text,
      data bytea NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  // Migrasi ringan untuk aplikasi yang sudah terlanjur berjalan (aman diulang).
  `ALTER TABLE orders ADD COLUMN IF NOT EXISTS share_token text`,
  `CREATE UNIQUE INDEX IF NOT EXISTS orders_share_token_key ON orders (share_token)`,
  `CREATE INDEX IF NOT EXISTS orders_status_idx ON orders (status)`,
  `CREATE INDEX IF NOT EXISTS orders_due_date_idx ON orders (due_date)`,
  `CREATE INDEX IF NOT EXISTS order_events_order_idx ON order_events (order_id)`,
  `CREATE INDEX IF NOT EXISTS order_photos_order_idx ON order_photos (order_id)`,
  // --- Foto di Vercel Blob (Oktober 2026) ---
  // Aditif dan aman diulang. Foto lama tetap di kolom data sampai
  // dipindahkan lewat tombol di Pengaturan.
  `ALTER TABLE order_photos ADD COLUMN IF NOT EXISTS blob_url text`,
  `ALTER TABLE order_photos ALTER COLUMN data DROP NOT NULL`,
  `CREATE TABLE IF NOT EXISTS production_partners (
      id serial PRIMARY KEY,
      name text NOT NULL,
      kind text NOT NULL DEFAULT 'vendor',
      phone text,
      address text,
      notes text,
      active boolean NOT NULL DEFAULT true,
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE TABLE IF NOT EXISTS outsource_jobs (
      id serial PRIMARY KEY,
      order_id integer NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
      partner_id integer REFERENCES production_partners(id) ON DELETE SET NULL,
      partner_name text NOT NULL,
      status text NOT NULL DEFAULT 'belum_dikirim',
      vendor_cost integer NOT NULL DEFAULT 0,
      sent_at timestamptz,
      expected_date date NOT NULL,
      expected_time text NOT NULL DEFAULT '12:00',
      received_at timestamptz,
      qc_result text,
      notes text,
      updated_at timestamptz NOT NULL DEFAULT now(),
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE INDEX IF NOT EXISTS outsource_jobs_status_idx ON outsource_jobs (status)`,
  `CREATE INDEX IF NOT EXISTS outsource_jobs_partner_idx ON outsource_jobs (partner_id)`,
  // --- Status per produk & multi mitra (Oktober 2026) ---
  // Semuanya aditif dan aman dijalankan berulang. Data lama tidak diubah:
  // status produk null = ikut status pekerjaan, dan mitra lama tanpa
  // produk terhubung = mengerjakan seluruh pekerjaan, persis seperti dulu.
  `ALTER TABLE order_items ADD COLUMN IF NOT EXISTS status text`,
  `ALTER TABLE order_items ADD COLUMN IF NOT EXISTS outsource_job_id integer REFERENCES outsource_jobs(id) ON DELETE SET NULL`,
  // Deadline khusus item (disalin dari invoice). null = ikut deadline pekerjaan.
  `ALTER TABLE order_items ADD COLUMN IF NOT EXISTS due_date date`,
  `ALTER TABLE order_items ADD COLUMN IF NOT EXISTS due_time text`,
  // Kunci baris invoice asal, supaya item baru tidak tersalin dua kali.
  `ALTER TABLE order_items ADD COLUMN IF NOT EXISTS source_line_key text`,
  `CREATE INDEX IF NOT EXISTS order_items_source_line_idx ON order_items (source_line_key)`,
  `CREATE INDEX IF NOT EXISTS order_items_outsource_idx ON order_items (outsource_job_id)`,
  // Lepas batas "1 mitra per pekerjaan". Nama constraint berbeda tergantung
  // tabel dibuat lewat /api/setup (…_key) atau drizzle-kit push (…_unique).
  `ALTER TABLE outsource_jobs DROP CONSTRAINT IF EXISTS outsource_jobs_order_id_key`,
  `ALTER TABLE outsource_jobs DROP CONSTRAINT IF EXISTS outsource_jobs_order_id_unique`,
  `CREATE INDEX IF NOT EXISTS outsource_jobs_order_idx ON outsource_jobs (order_id)`,
  `CREATE TABLE IF NOT EXISTS users (
      id serial PRIMARY KEY,
      name text NOT NULL,
      username text NOT NULL UNIQUE,
      password_hash text NOT NULL,
      role text NOT NULL DEFAULT 'karyawan',
      active boolean NOT NULL DEFAULT true,
      token_version integer NOT NULL DEFAULT 1,
      last_login_at timestamptz,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
   )`,
  // Migrasi role lama tanpa menghapus akun. token_version dinaikkan agar
  // sesi operator/kasir lama login ulang sebagai Karyawan.
  `ALTER TABLE users ALTER COLUMN role SET DEFAULT 'karyawan'`,
  `UPDATE users SET role = 'karyawan', token_version = token_version + 1, updated_at = now()
     WHERE role IN ('operator', 'kasir')`,
  `CREATE TABLE IF NOT EXISTS login_audit (
      id serial PRIMARY KEY,
      username text NOT NULL,
      user_id integer REFERENCES users(id) ON DELETE SET NULL,
      success boolean NOT NULL,
      ip text,
      user_agent text,
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE INDEX IF NOT EXISTS login_audit_created_idx ON login_audit (created_at)`,
  `CREATE TABLE IF NOT EXISTS push_subscriptions (
      id serial PRIMARY KEY,
      endpoint text NOT NULL UNIQUE,
      p256dh text NOT NULL,
      auth text NOT NULL,
      device_name text,
      operator_name text,
      user_agent text,
      active boolean NOT NULL DEFAULT true,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
   )`,
  `ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS user_id integer REFERENCES users(id) ON DELETE CASCADE`,
  `ALTER TABLE push_subscriptions ADD COLUMN IF NOT EXISTS user_role text`,
  `CREATE INDEX IF NOT EXISTS push_subscriptions_active_idx ON push_subscriptions (active)`,
  `CREATE INDEX IF NOT EXISTS push_subscriptions_user_idx ON push_subscriptions (user_id)`,
  `CREATE TABLE IF NOT EXISTS shift_handovers (
      id serial PRIMARY KEY,
      order_id integer NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      from_operator text NOT NULL,
      to_operator text NOT NULL,
      shift_label text,
      last_position text NOT NULL,
      blocker text,
      next_action text NOT NULL,
      note text,
      status text NOT NULL DEFAULT 'menunggu',
      handed_over_at timestamptz NOT NULL DEFAULT now(),
      accepted_at timestamptz,
      accepted_by text
   )`,
  `ALTER TABLE shift_handovers ADD COLUMN IF NOT EXISTS to_user_id integer REFERENCES users(id) ON DELETE SET NULL`,
  `CREATE INDEX IF NOT EXISTS shift_handovers_to_user_idx ON shift_handovers (to_user_id)`,
  `CREATE INDEX IF NOT EXISTS shift_handovers_order_idx ON shift_handovers (order_id)`,
  `CREATE INDEX IF NOT EXISTS shift_handovers_status_idx ON shift_handovers (status)`,
  `CREATE TABLE IF NOT EXISTS business_branding (
      id integer PRIMARY KEY DEFAULT 1,
      mime text NOT NULL DEFAULT 'image/png',
      size_bytes integer NOT NULL DEFAULT 0,
      data bytea NOT NULL,
      updated_at timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT business_branding_single_row CHECK (id = 1)
   )`,
  `ALTER TABLE order_photos ADD COLUMN IF NOT EXISTS uploaded_by text`,
  `CREATE TABLE IF NOT EXISTS user_sessions (
      id serial PRIMARY KEY,
      user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      ip text,
      user_agent text,
      created_at timestamptz NOT NULL DEFAULT now(),
      last_seen_at timestamptz NOT NULL DEFAULT now(),
      revoked_at timestamptz
   )`,
  `CREATE INDEX IF NOT EXISTS user_sessions_user_idx ON user_sessions (user_id)`,
  `CREATE INDEX IF NOT EXISTS user_sessions_revoked_idx ON user_sessions (revoked_at)`,
  // --- MODUL INVOICE (Oktober 2026) ---
  // Semuanya aditif dan aman dijalankan berulang. Tidak mengubah data lama.
  // Izin akun Karyawan membuka Invoice (Owner selalu boleh). Bawaan mati.
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS can_invoice boolean NOT NULL DEFAULT false`,
  // Penomoran: satu baris per hari WIB, diambil atomik saat invoice diterbitkan.
  `CREATE TABLE IF NOT EXISTS invoice_counters (
      period_key text PRIMARY KEY,
      last_seq integer NOT NULL DEFAULT 0
   )`,
  `CREATE TABLE IF NOT EXISTS invoices (
      id serial PRIMARY KEY,
      number text UNIQUE,
      status text NOT NULL DEFAULT 'draft',
      customer_id integer REFERENCES customers(id) ON DELETE SET NULL,
      customer_name text NOT NULL,
      customer_phone text,
      issue_date date NOT NULL,
      due_date date,
      pay_method text NOT NULL DEFAULT 'Transfer',
      subtotal integer NOT NULL DEFAULT 0,
      discount_rate numeric(6,3) NOT NULL DEFAULT 0,
      discount_amount integer NOT NULL DEFAULT 0,
      tax_rate numeric(6,3) NOT NULL DEFAULT 0,
      tax_amount integer NOT NULL DEFAULT 0,
      total integer NOT NULL DEFAULT 0,
      paid_amount integer NOT NULL DEFAULT 0,
      pay_status text NOT NULL DEFAULT 'belum',
      notes text,
      terms jsonb NOT NULL DEFAULT '[]'::jsonb,
      order_id integer REFERENCES orders(id) ON DELETE SET NULL,
      client_ref text UNIQUE,
      version integer NOT NULL DEFAULT 1,
      void_reason text,
      created_by text NOT NULL DEFAULT 'Owner',
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now(),
      issued_at timestamptz,
      voided_at timestamptz
   )`,
  // 1 invoice = 1 pekerjaan: satu pesanan hanya boleh tertaut ke satu invoice.
  `CREATE UNIQUE INDEX IF NOT EXISTS invoices_order_id_key ON invoices (order_id) WHERE order_id IS NOT NULL`,
  `CREATE INDEX IF NOT EXISTS invoices_status_idx ON invoices (status)`,
  `CREATE INDEX IF NOT EXISTS invoices_pay_status_idx ON invoices (pay_status)`,
  `CREATE INDEX IF NOT EXISTS invoices_issue_date_idx ON invoices (issue_date)`,
  // Daftar riwayat: ORDER BY created_at DESC, id DESC LIMIT 41. Tanpa index ini database
  // menyapu seluruh tabel lalu menyortir; dengan index ini cukup membaca 41 baris teratas.
  `CREATE INDEX IF NOT EXISTS invoices_created_at_id_idx ON invoices (created_at DESC, id DESC)`,
  `CREATE INDEX IF NOT EXISTS invoices_customer_idx ON invoices (customer_id)`,
  `CREATE TABLE IF NOT EXISTS invoice_items (
      id serial PRIMARY KEY,
      invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      position integer NOT NULL DEFAULT 0,
      line_key text,
      product_name text NOT NULL,
      description text,
      unit text NOT NULL DEFAULT 'pcs',
      qty numeric(14,3) NOT NULL DEFAULT 1,
      area_m2 numeric(14,4) NOT NULL DEFAULT 0,
      base_price integer NOT NULL DEFAULT 0,
      tiers jsonb,
      unit_price numeric(14,2) NOT NULL DEFAULT 0,
      amount integer NOT NULL DEFAULT 0,
      needs_production boolean NOT NULL DEFAULT true,
      prod_due_date date,
      prod_due_time text
   )`,
  `CREATE INDEX IF NOT EXISTS invoice_items_invoice_idx ON invoice_items (invoice_id)`,
  `CREATE TABLE IF NOT EXISTS payments (
      id serial PRIMARY KEY,
      invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      kind text NOT NULL DEFAULT 'bayar',
      amount integer NOT NULL CHECK (amount > 0),
      method text NOT NULL DEFAULT 'Transfer',
      paid_at timestamptz NOT NULL DEFAULT now(),
      note text,
      client_ref text UNIQUE,
      created_by text NOT NULL DEFAULT 'Owner',
      created_at timestamptz NOT NULL DEFAULT now(),
      voided_at timestamptz,
      voided_by text,
      void_reason text
   )`,
  `CREATE INDEX IF NOT EXISTS payments_invoice_idx ON payments (invoice_id)`,
  `CREATE TABLE IF NOT EXISTS invoice_events (
      id serial PRIMARY KEY,
      invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
      kind text NOT NULL,
      actor text NOT NULL DEFAULT 'Owner',
      detail text,
      created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE INDEX IF NOT EXISTS invoice_events_invoice_idx ON invoice_events (invoice_id)`,
  // --- MODUL INVOICE tahap B2: mode dokumen, diskon Rp, jadikan invoice ---
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS doc_type text NOT NULL DEFAULT 'invoice'`,
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS discount_type text NOT NULL DEFAULT 'persen'`,
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS discount_input numeric(14,3) NOT NULL DEFAULT 0`,
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS source_id integer REFERENCES invoices(id) ON DELETE SET NULL`,
  // Data tahap B (sebelum ada kolom discount_input): isian diskon = persentase yang tersimpan.
  `UPDATE invoices SET discount_input = discount_rate WHERE discount_input = 0 AND discount_rate > 0 AND discount_type = 'persen'`,
  `CREATE INDEX IF NOT EXISTS invoices_doc_type_idx ON invoices (doc_type)`,
  `CREATE INDEX IF NOT EXISTS invoices_source_idx ON invoices (source_id) WHERE source_id IS NOT NULL`,
  // --- MODUL INVOICE tahap C: tautan produksi ---
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS needs_production boolean NOT NULL DEFAULT false`,
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS prod_due_date date`,
  `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS prod_due_time text`,
  // --- Monitoring produksi PER ITEM ---
  // Item lama otomatis dianggap perlu produksi (true) supaya invoice lama
  // yang monitoringnya menyala tetap membuat pekerjaan seperti sebelumnya.
  `ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS needs_production boolean NOT NULL DEFAULT true`,
  `ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS prod_due_date date`,
  `ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS prod_due_time text`,
  `ALTER TABLE invoice_items ADD COLUMN IF NOT EXISTS line_key text`,
  `UPDATE invoice_items SET line_key = 'inv-' || id WHERE line_key IS NULL`,
  `CREATE INDEX IF NOT EXISTS invoice_items_line_key_idx ON invoice_items (invoice_id, line_key)`,
  // Pencocokan NAMA produk di baris invoice (riwayat harga produk fleksibel lewat dialog
  // "Set Harga"): pakai ekspresi yang SAMA dengan query pencocokannya supaya index terpakai.
  `CREATE INDEX IF NOT EXISTS invoice_items_name_lower_idx ON invoice_items (lower(btrim(product_name)))`,
  // --- MODUL INVOICE tahap E: katalog produk ---
  `CREATE TABLE IF NOT EXISTS invoice_products (
      id serial PRIMARY KEY,
      name text NOT NULL,
      description text,
      price integer NOT NULL DEFAULT 0,
      tiers jsonb,
      category text,
      image_data text,
      image_v integer NOT NULL DEFAULT 0,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
   )`,
  // Nama produk BOLEH sama asal keterangannya beda (mis. "Roll Banner" - "60x90" dan
  // "Roll Banner" - "80x200"). Yang ditolak hanya kombinasi nama + keterangan yang
  // sama persis (tidak peduli huruf besar/kecil & spasi pinggir; keterangan kosong = kosong).
  // Indeks lama (hanya nama) dibuang dulu; aman dijalankan berulang.
  `DROP INDEX IF EXISTS invoice_products_name_key`,
  `CREATE INDEX IF NOT EXISTS invoice_products_category_idx ON invoice_products (category)`,
  // --- Katalog: VARIAN (sub-kategori). Induk "Print HVS" -> varian "A4 Warna", "A4 Hitam Putih", dst. ---
  // Varian adalah produk biasa yang punya parent_id (harga + tier-nya milik sendiri). Induk adalah
  // baris dengan is_group = true tanpa harga: parent_id kosong = induk utama, parent_id terisi = sub-induk.
  // Kedalaman maksimal dua tingkat; aturan itu dijaga di invoice-catalog.ts.
  // Kunci asing ON DELETE SET NULL = pengaman: kalau induk terhapus, varian tidak ikut hilang diam-diam.
  `ALTER TABLE invoice_products ADD COLUMN IF NOT EXISTS parent_id integer REFERENCES invoice_products(id) ON DELETE SET NULL`,
  `ALTER TABLE invoice_products ADD COLUMN IF NOT EXISTS is_group boolean NOT NULL DEFAULT false`,
  `CREATE INDEX IF NOT EXISTS invoice_products_parent_idx ON invoice_products (parent_id)`,
  // Aturan unik sekarang PER INDUK: nama + keterangan harus beda di dalam satu induk (atau di tingkat
  // atas bila tanpa induk). Jadi "A4 Warna" boleh ada di bawah "Print HVS" DAN di bawah "Fotocopy".
  // Indeks baru lebih longgar dari yang lama, jadi pasti bisa dibuat di data yang sudah ada.
  // Indeks lama (nama + keterangan se-katalog) dibuang SETELAH yang baru jadi. Aman dijalankan berulang.
  `CREATE UNIQUE INDEX IF NOT EXISTS invoice_products_scope_name_desc_key ON invoice_products ((coalesce(parent_id, 0)), (lower(btrim(name))), (lower(btrim(coalesce(description, '')))))`,
  `DROP INDEX IF EXISTS invoice_products_name_desc_key`,
  // --- Harga FLEKSIBEL: jasa tanpa harga baku (mis. jasa desain), operator menetapkan harga saat menjual.
  // "tetap" (bawaan semua baris lama) = harga katalog seperti biasa. price_presets = pilihan cepat dari owner.
  `ALTER TABLE invoice_products ADD COLUMN IF NOT EXISTS pricing_mode text NOT NULL DEFAULT 'tetap'`,
  `ALTER TABLE invoice_products ADD COLUMN IF NOT EXISTS price_presets jsonb`,
  // Teks pengganti gambar: kartu tanpa gambar menampilkan teks besar (SVG murni, tanpa file baru).
  `ALTER TABLE invoice_products ADD COLUMN IF NOT EXISTS image_text text`,
  // --- Pembayaran: nomor referensi transaksi (RRN / ID transaksi QRIS atau bank). Opsional. ---
  `ALTER TABLE payments ADD COLUMN IF NOT EXISTS reference text`,
  `CREATE INDEX IF NOT EXISTS payments_reference_idx ON payments (lower(reference)) WHERE reference IS NOT NULL`,
];

type SeedCustomer = [string, string | null, string | null, string, string];

const SEED_CUSTOMERS: SeedCustomer[] = [
  ["Toko Berkah Jaya", "081234567890", "berkahjaya@mail.com", "Jl. Pasar Baru 12", "Pelanggan langganan spanduk, harga khusus"],
  ["Kantor Desa Sukamaju", "081298765432", null, "Kantor Desa Sukamaju", "Selalu minta invoice"],
  ["Kopi Senja", "085612345678", "kopisenja@mail.com", "Jl. Merdeka 45", "Order menu & stiker gelas"],
  ["SMP Negeri 3", "081377788899", null, "Jl. Pendidikan 8", "Musiman: awal tahun ajaran"],
  ["Bu Rina (Event Organizer)", "087812345678", "rina.eo@mail.com", "Jl. Cempaka 3", "Urgent biasanya, bayar DP 50%"],
];

type SeedOrderItem = { productType: string; quantity: number; unit: string };

type SeedOrder = {
  customer: string;
  title: string;
  items: SeedOrderItem[];
  machine: string;
  operator: string | null;
  status: string;
  priority: string;
  price: number;
  paidAmount: number;
  dayOffset: number;
  dueTime: string;
  estHours: number;
  notes: string | null;
};

const SEED_ORDERS: SeedOrder[] = [
  { customer: "Bu Rina (Event Organizer)", title: "Backdrop seminar 3x2 meter", items: [{ productType: "Spanduk / Banner", quantity: 2, unit: "pcs" }], machine: "Large Format / Outdoor", operator: "Yoga", status: "cetak", priority: "urgent", price: 900000, paidAmount: 450000, dayOffset: 0, dueTime: "15:00", estHours: 6, notes: "Desain sudah OK. Butuh mata ayam & tali." },
  { customer: "Kopi Senja", title: "Stiker gelas 300 pcs", items: [{ productType: "Stiker / Label", quantity: 300, unit: "pcs" }], machine: "Digital Print 1", operator: "Dimas", status: "finishing", priority: "normal", price: 450000, paidAmount: 450000, dayOffset: 1, dueTime: "17:00", estHours: 5, notes: "Bahan vinyl glossy, potong kiss-cut." },
  // Contoh 1 pekerjaan berisi BEBERAPA jenis produk sekaligus (fitur multi-item).
  { customer: "Toko Berkah Jaya", title: "Order Pak Budi — paket promosi toko", items: [
      { productType: "Spanduk / Banner", quantity: 2, unit: "pcs" },
      { productType: "Stiker / Label", quantity: 500, unit: "lembar" },
      { productType: "Kartu Nama", quantity: 1, unit: "box" },
    ], machine: "Digital Print 2", operator: "Bu Rina", status: "siap", priority: "normal", price: 950000, paidAmount: 950000, dayOffset: -1, dueTime: "16:00", estHours: 8, notes: "Sudah dilaminasi doff. 1x kirim WA untuk semua item." },
  { customer: "Kantor Desa Sukamaju", title: "Buku profil desa 10 eksemplar", items: [{ productType: "Buku / Yasinan", quantity: 10, unit: "set" }], machine: "Mesin Offset", operator: "Pak Andi", status: "antrian", priority: "tinggi", price: 3200000, paidAmount: 1000000, dayOffset: 4, dueTime: "14:00", estHours: 22, notes: "Menunggu file revisi bab 2 dari sekretaris." },
  { customer: "SMP Negeri 3", title: "Sertifikat lomba 120 lembar", items: [{ productType: "Nota / Kop Surat", quantity: 120, unit: "lembar" }], machine: "Digital Print 1", operator: "Dimas", status: "desain", priority: "normal", price: 600000, paidAmount: 0, dayOffset: 2, dueTime: "10:00", estHours: 6, notes: "Menunggu daftar nama pemenang." },
  { customer: "Toko Berkah Jaya", title: "Nota NPL 40 blok", items: [{ productType: "Nota / Kop Surat", quantity: 40, unit: "box" }], machine: "Mesin Offset", operator: "Pak Andi", status: "selesai", priority: "normal", price: 880000, paidAmount: 880000, dayOffset: -3, dueTime: "17:00", estHours: 9, notes: "Sudah diambil sendiri oleh pemilik toko." },
  { customer: "Bu Rina (Event Organizer)", title: "Undangan pernikahan klien 250 pcs", items: [{ productType: "Undangan", quantity: 250, unit: "pcs" }], machine: "Finishing & Binding", operator: "Tim Finishing", status: "ditunda", priority: "tinggi", price: 3750000, paidAmount: 1500000, dayOffset: -1, dueTime: "12:00", estHours: 26, notes: "Menunggu pelunasan DP kedua sebelum produksi." },
  { customer: "Kopi Senja", title: "Banner promo grand opening", items: [{ productType: "Spanduk / Banner", quantity: 3, unit: "meter" }], machine: "Large Format / Outdoor", operator: "Yoga", status: "qc", priority: "normal", price: 300000, paidAmount: 300000, dayOffset: 1, dueTime: "17:00", estHours: 4, notes: "Cek hasil warna sebelum diserahkan." },
];

export async function GET(request: Request) {
  const url = new URL(request.url);
  const token = process.env.SETUP_TOKEN;
  if (token) {
    const provided = url.searchParams.get("token");
    if (provided !== token) {
      return Response.json({ ok: false, error: "Token setup salah. Tambahkan ?token=..." }, { status: 401 });
    }
  }

  try {
    for (const statement of DDL) {
      await db.execute(sql.raw(statement));
    }

    let seeded = false;
    if (url.searchParams.get("seed") === "1") {
      const existing = await db.execute<{ count: string }>(sql`select count(*)::text as count from orders`);
      const rows = existing.rows as { count: string }[];
      if (Number.parseInt(rows[0]?.count ?? "0", 10) === 0) {
        const customerIds = new Map<string, number>();
        for (const [name, phone, email, address, notes] of SEED_CUSTOMERS) {
          const result = await db.execute<{ id: number }>(sql`
            insert into customers (name, phone, email, address, notes)
            values (${name}, ${phone}, ${email}, ${address}, ${notes})
            returning id
          `);
          const inserted = (result.rows as { id: number }[])[0];
          if (inserted) customerIds.set(name, inserted.id);
        }

        const year = new Date().getFullYear();
        let index = 1;
        for (const order of SEED_ORDERS) {
          const code = `PJ-${year}-${String(index).padStart(4, "0")}`;
          const result = await db.execute<{ id: number }>(sql`
            insert into orders (
              code, customer_id, customer_name, title, machine,
              operator, status, priority, price, paid_amount, due_date, due_time, est_hours, notes
            ) values (
              ${code},
              ${customerIds.get(order.customer) ?? null},
              ${order.customer},
              ${order.title},
              ${order.machine},
              ${order.operator},
              ${order.status},
              ${order.priority},
              ${order.price},
              ${order.paidAmount},
              (current_date + ${order.dayOffset} * interval '1 day')::date,
              ${order.dueTime},
              ${order.estHours},
              ${order.notes}
            )
            returning id
          `);
          const inserted = (result.rows as { id: number }[])[0];
          if (inserted) {
            let position = 0;
            for (const item of order.items) {
              await db.execute(sql`
                insert into order_items (order_id, product_type, quantity, unit, position)
                values (${inserted.id}, ${item.productType}, ${item.quantity}, ${item.unit}, ${position})
              `);
              position += 1;
            }
            await db.execute(sql`
              insert into order_events (order_id, from_status, to_status, note, actor)
              values (${inserted.id}, null, 'antrian', 'Pekerjaan dibuat & masuk antrian.', 'Owner')
            `);
            if (order.status !== "antrian") {
              await db.execute(sql`
                insert into order_events (order_id, from_status, to_status, note, actor)
                values (${inserted.id}, 'antrian', ${order.status}, 'Data contoh untuk belajar.', 'Owner')
              `);
            }
          }
          index += 1;
        }
        seeded = true;
      }
    }

    return Response.json({
      ok: true,
      message: "Database siap dipakai. Semua tabel sudah dibuat.",
      tables: [
        "customers",
        "orders",
        "order_items",
        "order_events",
        "ai_notes",
        "settings",
        "order_photos",
        "production_partners",
        "outsource_jobs",
        "users",
        "login_audit",
        "push_subscriptions",
        "shift_handovers",
        "business_branding",
        "user_sessions",
        "invoice_counters",
        "invoices",
        "invoice_items",
        "payments",
        "invoice_events",
        "invoice_products",
      ],
      seeded,
      hint: seeded ? "Contoh data sudah diisi. Buka halaman utama aplikasi." : "Untuk mengisi contoh data, buka /api/setup?seed=1",
    });
  } catch (error) {
    console.error("GET /api/setup", error);
    return Response.json(
      { ok: false, error: "Gagal menyiapkan database.", detail: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  return GET(request);
}
