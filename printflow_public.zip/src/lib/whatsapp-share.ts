import { statusMeta } from "@/lib/domain";
import { formatItem, type OrderItem } from "@/lib/order-items";

export type ShareOrder = {
  id: number;
  code: string;
  title: string;
  customerName: string;
  status: string;
  dueDate: string;
  dueTime: string;
  /**
   * Rincian produk di dalam pekerjaan. Sejak "jenis produk" dihapus dari
   * tabel pekerjaan, isi pesan WhatsApp diambil dari daftar ini — jadi
   * pelanggan melihat SEMUA barang yang dipesannya dalam satu pesan,
   * bukan cuma satu jenis produk seperti versi sebelumnya.
   */
  items: OrderItem[];
};

/** Susun teks pesan WhatsApp untuk kabar status pekerjaan ke pelanggan. */
export function buildWhatsAppMessage(order: ShareOrder, url: string): string {
  const meta = statusMeta(order.status);
  const selesai = order.status === "selesai";
  // "Siap" = kabar akhir yang dilihat pelanggan (selesai = penanda internal
  // barang sudah diserahkan), jadi pesannya diperlakukan sama seperti selesai.
  const siap = order.status === "siap";
  const kelar = selesai || siap;
  const items = order.items ?? [];

  // Satu item: ditulis inline supaya pesan tetap pendek.
  // Banyak item: ditulis sebagai daftar bernomor agar mudah dicek pelanggan
  // satu per satu saat barang diterima.
  const rincian =
    items.length === 0
      ? []
      : items.length === 1
        ? [`• Pesanan     : ${formatItem(items[0])}`]
        : [
            `• Rincian (${items.length} item):`,
            ...items.map((item, index) => `   ${index + 1}. ${formatItem(item)}`),
          ];

  const lines = [
    `Halo ${order.customerName} 👋`,
    "",
    selesai
      ? `Pesanan Anda *${order.title}* sudah *SELESAI* ✅ dan siap diambil / dikirim.`
      : siap
        ? `Pesanan Anda *${order.title}* sudah *SIAP* 📦 dan bisa diambil / dikirim.`
        : `Berikut kabar terbaru pesanan Anda di percetakan kami:`,
    "",
    `• No. pesanan : ${order.code}`,
    `• Pekerjaan   : ${order.title}`,
    ...rincian,
    `• Status      : ${meta.emoji} ${meta.label}`,
    "",
    kelar && items.length > 1
      ? `Mohon dicek kembali kelengkapan ${items.length} item di atas saat serah terima ya 🙏`
      : undefined,
    kelar
      ? "Silakan lihat foto hasilnya di tautan ini 👇"
      : "Anda bisa memantau progres & foto pesanan lewat tautan ini 👇",
    url,
    "",
    "Terima kasih sudah memesan 🙏",
  ];
  return lines.filter((l) => l !== undefined).join("\n");
}

/**
 * Versi tampilan tautan lacak.
 *
 * WhatsApp menyimpan pratinjau (judul, deskripsi, ikon) per URL. Kalau
 * branding halaman /lacak diubah tetapi URL-nya tetap sama, tautan yang
 * dibagikan berikutnya masih bisa memakai pratinjau lama. Naikkan angka ini
 * setiap kali branding pratinjau berubah supaya tautan baru memakai URL baru
 * dan WhatsApp mengambil metadata terbaru.
 */
export const TRACKING_LINK_VERSION = "4";

/** URL publik halaman lacak + versi pratinjau WhatsApp. */
export function buildTrackingUrl(origin: string, token: string): string {
  return `${origin}/lacak/${token}?v=${TRACKING_LINK_VERSION}`;
}

/** Minta (atau ambil) token lacak lewat endpoint idempoten, lalu susun URL publiknya. */
export async function ensureTrackingUrl(orderId: number, existingToken: string | null): Promise<{ token: string; url: string } | null> {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  if (existingToken) return { token: existingToken, url: buildTrackingUrl(origin, existingToken) };
  const res = await fetch(`/api/orders/${orderId}/share`, { method: "POST" });
  const json = (await res.json()) as { ok: boolean; token?: string; error?: string };
  if (!json.ok || !json.token) return null;
  return { token: json.token, url: buildTrackingUrl(origin, json.token) };
}

/**
 * Nama tab tetap untuk semua pengiriman WA dari PrintFlow. Dipakai sebagai
 * target `window.open()` (ganti `"_blank"`) supaya klik berikutnya membuka
 * kembali TAB YANG SAMA (tinggal dialihkan ke pesan baru), bukan bikin tab
 * baru terus-menerus. Catatan: ini hanya bisa "mengenali" tab yang memang
 * dibuka lewat tombol ini sebelumnya di sesi browser yang sama — tab WhatsApp
 * Web yang dibuka manual (ketik sendiri di address bar) tidak akan otomatis
 * kesambung; baru klik BERIKUTNYA setelah itu yang akan reuse tab tersebut.
 */
export const WHATSAPP_SHARE_WINDOW = "printflow_whatsapp_share";

export type ShareOutcome = "opened" | "copied" | "failed";

/**
 * Arahkan ke wa.me dengan pesan yang sudah disusun.
 *
 * `preOpenedWindow`: tab yang HARUS sudah dibuka lewat
 * `window.open("", WHATSAPP_SHARE_WINDOW)` SAAT MASIH di dalam event klik
 * pengguna — sebelum ada proses async (fetch token) berjalan. Ini wajib:
 * kalau `window.open()` baru dipanggil setelah `await`, beberapa browser
 * (terutama Safari, dan kadang Chrome di kondisi tertentu) sudah tidak
 * menganggapnya sebagai hasil klik langsung pengguna lagi ("kehilangan user
 * activation"), jadi diam-diam diblokir. Pakai nama target yang konsisten
 * (bukan "_blank") juga membuat browser reuse tab yang sama tiap kali,
 * bukan membuka tab baru setiap klik.
 *
 * Sengaja TIDAK pakai Web Share API (`navigator.share`) di sini — selain
 * kena masalah "gesture" yang sama begitu dipanggil setelah `await`, tombolnya
 * memang spesifik "Kirim WA", jadi langsung ke WhatsApp lebih pasti daripada
 * memunculkan menu share umum OS yang belum tentu ada WhatsApp-nya / bisa
 * gagal senyap di sebagian browser desktop.
 *
 * Kalau ternyata tab yang disiapkan gagal dibuka sama sekali (popup benar-benar
 * diblokir), pesan otomatis disalin ke clipboard sebagai jalan terakhir supaya
 * pengguna masih bisa kirim manual.
 */
export async function openWhatsAppShare(order: ShareOrder, url: string, preOpenedWindow?: Window | null): Promise<ShareOutcome> {
  const waUrl = `https://wa.me/?text=${encodeURIComponent(buildWhatsAppMessage(order, url))}`;
  if (preOpenedWindow && !preOpenedWindow.closed) {
    preOpenedWindow.location.href = waUrl;
    preOpenedWindow.focus?.();
    return "opened";
  }
  // Tab tadi entah kenapa gagal/tertutup — coba sekali lagi langsung, siapa tahu diizinkan.
  const fallback = window.open(waUrl, WHATSAPP_SHARE_WINDOW);
  if (fallback) return "opened";
  try {
    await navigator.clipboard.writeText(buildWhatsAppMessage(order, url));
    return "copied";
  } catch {
    return "failed";
  }
}
