import { CircleCheck, Mail, MapPin, MessageCircle, Receipt, User } from "lucide-react";
import { PaperLogo } from "@/components/PaperLogo";
import { InvoicePayPanel } from "@/components/InvoicePayPanel";
import { InvoiceSignature } from "@/components/InvoiceSignature";
import { AccentLastWord } from "@/components/AccentLastWord";
import { DraggableStamp, StampHint } from "@/components/DraggableStamp";
import { customerLabel, formatDateID, formatRupiah } from "@/lib/domain";
import { docModeOf } from "@/lib/invoice-modes";
import { computePayInfo } from "@/lib/invoice-pay";
import type { InvoiceDetail } from "@/lib/invoice-queries";
import type { InvoiceSettings } from "@/lib/invoice-settings";
import { computeRowPricing } from "@/lib/invoice-pricing";

/**
 * KERTAS DOKUMEN (tampilan baca) - bentuknya sama dengan editor.
 * Server component murni: hanya menampilkan data yang sudah dihitung server.
 *  - Data customer di lembar HANYA tampil bila pengaturan "Tampilkan data customer
 *    di lembar cetak" menyala. Bar customer di layar tidak ikut tercetak.
 *  - Surat Jalan: tanpa harga/jumlah/total, ada kolom "Diterima oleh".
 */
export function InvoicePaper({ detail, settings, isOwner = false }: { detail: InvoiceDetail; settings: InvoiceSettings; isOwner?: boolean }) {
  const { invoice, items, summary } = detail;
  const mode = docModeOf(invoice.docType);
  const isDraft = invoice.status === "draft";
  const isVoid = invoice.status === "batal";
  /* minmax(0, Nfr) - bukan "Nfr" polos, supaya lebar tiap trek hanya
   bergantung pada --ppi-cols dan tidak melebar karena isi sel. Tanpa
   itu, .ppi-thead dan .ppi-row (dua grid terpisah) bisa menghitung trek
   berbeda dan kolomnya tidak lurus. Pecahan di bawah memberi ruang cukup
   supaya tiap judul kolom tetap satu baris di lebar desktop. */
  const cols = mode.showPrices
    ? "minmax(0,24fr) minmax(0,21fr) minmax(0,13fr) minmax(0,7fr) minmax(0,16fr) minmax(0,13fr)"
    : "minmax(0,40fr) minmax(0,36fr) minmax(0,14fr) minmax(0,10fr)";
  const addressLines = settings.address.split(/\r?\n/).filter(Boolean);
  const payInfo = computePayInfo({
    total: invoice.total,
    paid: summary.paid,
    method: invoice.payMethod,
    number: invoice.number,
    uniqueCodeEnabled: settings.uniqueCode,
  });

  const stamp = isVoid ? { t: "BATAL", c: "border-rose-600 text-rose-600" } : isDraft ? { t: "DRAFT", c: "border-slate-500 text-slate-500" } : mode.hasPayments && summary.status === "lunas" ? { t: "LUNAS", c: "border-emerald-600 text-emerald-600" } : null;

  return (
    <>
      {/* Padding HP lebih rapat (16px / 20px / 24px). Kertas ini duduk di
          dalam main yang sudah punya padding sendiri, jadi di 360px
          tambah 32px per sisi membuat area isinya cuma ~296px.
          sm: mengembalikan nilai yang lebih longgar di layar lebar.
          CETAK/PDF tidak terpengaruh: iframe cetak memaksa padding
          10mm/11mm dengan !important (lihat invoice-output.ts). */}
      <article id="ppi-paper" className="ppi-paper px-4 pb-6 pt-5 sm:px-8 sm:pb-8 sm:pt-8">
        {stamp ? <DraggableStamp text={stamp.t} className={`right-6 top-24 ${stamp.c}`} /> : null}

        <header className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
          {/* Kop perusahaan (logo + nama + alamat + kontak). Di layar HP
              disembunyikan supaya kertasnya terbaca sebagai form isian,
              bukan dokumen - lihat blok "@media screen and (max-width:639px)"
              di globals.css. Saat CETAK/PDF blok itu tidak berlaku, jadi
              kop ini tetap ikut ke dokumen. */}
          <div className="ppi-brand flex min-w-0 gap-3">
            <PaperLogo />
            <div className="min-w-0 space-y-0.5 text-xs text-slate-600">
              <p className="break-words text-lg font-extrabold text-slate-900"><AccentLastWord text={settings.businessName} /></p>
              {addressLines.length ? (
                /* Setiap baris alamat jadi baris sendiri. Dulu diringkas
                   jadi satu kalimat dengan join(", ") sehingga hasil Enter
                   di Pengaturan hilang begitu disimpan. min-w-0 diperlukan
                   supaya baris yang panjang tetap bisa wrap di dalam flex. */
                <p className="flex items-start gap-2">
                  <MapPin size={13} className="mt-0.5 shrink-0 text-[color:var(--ppi-accent)]" />
                  <span className="min-w-0">
                    {addressLines.map((line, i) => (
                      <span key={i} className="block break-words leading-relaxed">{line}</span>
                    ))}
                  </span>
                </p>
              ) : null}
              {settings.email ? <p className="flex items-center gap-2"><Mail size={13} className="shrink-0 text-[color:var(--ppi-accent)]" /><span className="break-all">{settings.email}</span></p> : null}
              {settings.phone ? <p className="flex items-center gap-2"><MessageCircle size={13} className="shrink-0 text-[color:var(--ppi-accent)]" />{settings.phone}</p> : null}
            </div>
          </div>
          <div className="sm:w-[330px] sm:text-right">
            {/* Judul jenis dokumen ("INVOICE"). Di HP sudah tampil di
                ringkasan sticky di atas, jadi di sini disembunyikan agar
                tidak ter thrice. sm: ke atas dan cetakan tetap tampil. */}
            {/* Judul jenis dokumen ("INVOICE"). Di HP sudah tampil di
                ringkasan sticky di atas, jadi di sini disembunyikan agar
                tidak terulang tiga kali. sm: ke atas dan cetakan tetap tampil. */}
            <div className="ppi-meta mt-3 text-xs">
              <div className="ppi-meta-row">
                <span className="ppi-meta-label">No. {mode.label.split(" ")[0]}</span>
                <b className="ppi-in boxed ppi-num min-w-0 flex-1 !py-1.5 sm:max-w-[190px]">{invoice.number ?? `Draft #${invoice.id}`}</b>
              </div>
              <div className="ppi-meta-row">
                <span className="ppi-meta-label">{mode.dateLabel}</span>
                <b className="ppi-in boxed ppi-num min-w-0 flex-1 !py-1.5 sm:max-w-[190px]">{formatDateID(invoice.issueDate)}</b>
              </div>
              {mode.dueLabel ? (
                <div className="ppi-meta-row">
                  <span className="ppi-meta-label">{mode.dueLabel}</span>
                  <b className="ppi-in boxed ppi-num min-w-0 flex-1 !py-1.5 sm:max-w-[190px]">{invoice.dueDate ? formatDateID(invoice.dueDate) : "—"}</b>
                </div>
              ) : null}
            </div>
          </div>
        </header>

        {/* ===== Tabel ===== */}
        <section className="mt-6">
          <div className="ppi-thead" style={{ "--ppi-cols": cols } as React.CSSProperties}>
            <span>Produk</span>
            <span>Keterangan</span>
            <span className="text-right">M² Bahan</span>
            <span className="text-right">Qty</span>
            {mode.showPrices ? <span className="text-right">Harga satuan</span> : null}
            {mode.showPrices ? <span className="text-right">Jumlah</span> : null}
          </div>
          {items.map((it) => {
            const p = computeRowPricing({ qty: it.qty, areaM2: it.areaM2, basePrice: it.basePrice, tiers: it.tiers });
            return (
              <div key={it.id} className="ppi-rowwrap py-2 md:py-1">
                <div className="ppi-row" style={{ "--ppi-cols": cols } as React.CSSProperties}>
                  <div className="ppi-c-wide py-1.5 text-[13px] font-semibold text-slate-900"><span className="ppi-mlabel">Produk</span><span className="whitespace-pre-line break-words">{it.productName}</span></div>
                  <div className="ppi-c-wide py-1.5 text-[13px] text-slate-600"><span className="ppi-mlabel">Keterangan</span><span className="whitespace-pre-line break-words">{it.description || "—"}</span></div>
                  <div className="py-1.5 text-right text-[13px]"><span className="ppi-mlabel">M² bahan</span>{it.areaM2 > 0 ? String(it.areaM2).replace(".", ",") : "—"}</div>
                  <div className="py-1.5 text-right text-[13px]"><span className="ppi-mlabel">Qty</span>{String(it.qty).replace(".", ",")}</div>
                  {mode.showPrices ? (
                    <>
                      <div className="py-1.5 text-right text-[13px]">
                        <span className="ppi-mlabel">Harga satuan</span>
                        {formatRupiah(Math.round(it.unitPrice))}
                        {p.hasTier && p.tier ? <span className="block text-[10px] font-semibold text-teal-700">{p.label}</span> : null}
                      </div>
                      {/* Sel "Jumlah" di HP jadi baris tersendiri yang
                          melebar penuh: label di kiri, nominal besar di
                          kanan, dipisah garis putus. Di desktop kelas
                          ppi-c-total dikembalikan jadi sel biasa oleh
                          blok @media (min-width:768px) DAN oleh blok
                          @media print di globals.css - kalau salah satu
                          lupa, hasil cetak ikut berubah jadi satu baris. */}
                      <div className="ppi-c-total text-[13px] font-extrabold text-slate-900">
                        <span className="ppi-mlabel">Jumlah</span>
                        <span>{formatRupiah(it.amount)}</span>
                      </div>
                    </>
                  ) : null}
                </div>
              </div>
            );
          })}
          {mode.showTotals ? (
            <div className="flex items-center justify-between gap-2 border-t border-slate-100 px-3 pt-3 text-xs text-slate-500">
              <span>{items.length} item</span>
              <span className="text-base font-extrabold text-slate-900">{formatRupiah(invoice.subtotal)}</span>
            </div>
          ) : null}
        </section>

        {/* ===== Data customer (bar layar; di lembar hanya bila diizinkan pengaturan) ===== */}
        <div className="ppi-dashed ppi-screen-only mt-4 flex items-center gap-3 px-4 py-3">
          <User size={18} className="shrink-0 text-[color:var(--ppi-accent)]" />
          <span className="min-w-0 flex-1">
            <span className="ppi-kicker">Data Customer</span>
            <span className={`block truncate text-sm font-bold ${invoice.customerName.trim() ? "text-slate-800" : "text-slate-500"}`}>
              {customerLabel(invoice.customerName)}{invoice.customerPhone ? ` · ${invoice.customerPhone}` : ""}
            </span>
            <span className="block text-[10.5px] text-slate-500">
              {invoice.customerName.trim()
                ? settings.showCustomerOnPrint
                  ? "Ikut tercetak di lembar dokumen."
                  : "Tidak ikut tercetak (bisa diubah di Pengaturan > Dokumen)."
                : "Data customer tidak diisi."}
            </span>
          </span>
        </div>
        {settings.showCustomerOnPrint && invoice.customerName.trim() ? (
          <div className="mt-3 text-xs text-slate-600">
            <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Kepada</p>
            <p className="font-bold text-slate-900">{invoice.customerName}</p>
            {invoice.customerPhone ? <p>{invoice.customerPhone}</p> : null}
          </div>
        ) : null}

        {/* ===== Pembayaran + total ===== */}
        {mode.showTotals ? (
          <section className={`mt-6 grid items-start gap-4 ${mode.hasPayments ? "md:grid-cols-2" : ""}`}>
            {mode.hasPayments ? (
              <InvoicePayPanel
                info={payInfo}
                settings={settings}
                isOwner={isOwner}
                showAmountBox={!isDraft && !isVoid}
                methodSlot={
                  <div>
                    <span className="ppi-kicker">Metode Pembayaran</span>
                    <p className="mt-2 flex items-center gap-2 rounded-xl border border-[color:var(--ppi-line)] bg-[color:var(--ppi-fill)] px-3 py-2.5 text-sm font-bold text-slate-900"><Receipt size={15} className="text-[color:var(--ppi-accent)]" /> {invoice.payMethod}</p>
                  </div>
                }
              />
            ) : null}

            <div className={mode.hasPayments ? "" : "md:ml-auto md:w-[380px]"}>
              <div className="ppi-panel space-y-2.5 text-sm">
                <div className="flex items-baseline justify-between gap-2"><span className="text-slate-600">Subtotal <span className="text-[10.5px] text-slate-400">(Sebelum Diskon &amp; Pajak)</span></span><b>{formatRupiah(invoice.subtotal)}</b></div>
                {invoice.discountAmount > 0 ? (
                  <div className="flex items-baseline justify-between gap-2 text-slate-600"><span>Diskon {invoice.discountType === "persen" ? `${invoice.discountRate}%` : "(Rp)"}</span><span>- {formatRupiah(invoice.discountAmount)}</span></div>
                ) : null}
                {invoice.taxAmount > 0 ? (
                  <div className="flex items-baseline justify-between gap-2 text-slate-600"><span>PPN {invoice.taxRate}%</span><span>{formatRupiah(invoice.taxAmount)}</span></div>
                ) : null}
                <div className="flex items-baseline justify-between gap-2 border-t border-slate-200 pt-3">
                  <span className="text-sm font-extrabold uppercase tracking-wide text-[color:var(--ppi-accent)]">Total Akhir</span>
                  <span className="text-xl font-black text-slate-900">{formatRupiah(invoice.total)}</span>
                </div>
                {mode.hasPayments && !isDraft ? (
                  <>
                    <div className="flex justify-between text-emerald-700"><span>Terbayar</span><span>{formatRupiah(summary.paid)}</span></div>
                    <div className={`flex justify-between font-bold ${summary.remaining > 0 && !isVoid ? "text-rose-600" : "text-slate-500"}`}><span>Sisa tagihan</span><span>{formatRupiah(summary.remaining)}</span></div>
                  </>
                ) : null}
              </div>
            </div>
          </section>
        ) : (
          <section className="mt-8 grid grid-cols-2 gap-6 text-center text-xs text-slate-700">
            <div><p>Pengirim,</p><div className="h-16" /><p className="border-t border-slate-400 pt-1 font-bold">{settings.businessName}</p></div>
            <div><p>Diterima oleh,</p><div className="h-16" /><p className="border-t border-slate-400 pt-1 font-bold">(nama &amp; tanda tangan)</p></div>
          </section>
        )}

        <InvoiceSignature settings={settings} />

        {invoice.terms.length || invoice.notes ? (
          <section className="ppi-panel mt-5">
            <p className="ppi-kicker">Syarat & Ketentuan</p>
            <ul className="mt-3">
              {invoice.terms.map((t, i) => (
                <li key={i} className="ppi-term"><CircleCheck size={15} strokeWidth={2.2} />{t}</li>
              ))}
            </ul>
            {invoice.notes ? <p className="mt-3 whitespace-pre-line text-[11px] text-slate-500">Catatan: {invoice.notes}</p> : null}
          </section>
        ) : null}

        {isVoid && invoice.voidReason ? <p className="mt-4 rounded-xl bg-rose-50 p-3 text-xs font-semibold text-rose-700">Dibatalkan: {invoice.voidReason}</p> : null}
      </article>

      {/* Petunjuk DI LUAR kertas: kalau ditaruh di dalam, ia menambah tinggi
          kertas saat tampil di layar tapi hilang saat dicetak - hasil cetaknya
          lalu berbeda dari layar. */}
      {stamp ? <StampHint /> : null}
    </>
  );
}
